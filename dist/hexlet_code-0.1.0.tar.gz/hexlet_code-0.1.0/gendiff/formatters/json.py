import json


def json_formater(diff):
    return json.dumps(diff, indent=4)
