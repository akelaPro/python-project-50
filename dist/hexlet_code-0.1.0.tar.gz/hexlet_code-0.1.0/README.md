### Hexlet tests and linter status:
[![Actions Status](https://github.com/akelaPro/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/akelaPro/python-project-50/actions)

<a href="https://codeclimate.com/github/akelaPro/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/ec31fbff93f94d979584/maintainability" /></a>

<a href="https://codeclimate.com/github/akelaPro/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/ec31fbff93f94d979584/test_coverage" /></a>